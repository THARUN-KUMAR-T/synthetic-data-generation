const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Serve static frontend files
app.use(express.static(path.join(__dirname, '../portal')));

// API to get list of problems
app.get('/api/problems', (req, res) => {
    const problemsDir = path.join(__dirname, '../problems');
    try {
        const folders = fs.readdirSync(problemsDir).filter(f => fs.statSync(path.join(problemsDir, f)).isDirectory());
        
        const problems = folders.map(folder => {
            const mdPath = path.join(problemsDir, folder, 'problem.md');
            let content = '';
            let title = folder;
            let difficulty = 'Medium';
            let category = '';
            
            if (fs.existsSync(mdPath)) {
                content = fs.readFileSync(mdPath, 'utf8');
                const titleMatch = content.match(/^#\s+(.+)$/m);
                if (titleMatch) title = titleMatch[1];
                
                const diffMatch = content.match(/^##\s+Difficulty:\s+(.+)$/m);
                if (diffMatch) difficulty = diffMatch[1];

                const catMatch = content.match(/^##\s+Category:\s+(.+)$/m);
                if (catMatch) category = catMatch[1];
            }
            
            return { id: folder, title, difficulty, category };
        });
        
        res.json(problems);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// Helper to extract examples from markdown
function extractExamples(markdown) {
    const examples = [];
    // Matches **Input:**\n```\n(content)\n```
    const regex = /\*\*Input:\*\*\s*```[\s\S]*?\n([\s\S]*?)\n```/g;
    let match;
    while ((match = regex.exec(markdown)) !== null) {
        examples.push(match[1]);
    }
    return examples;
}

// API to get specific problem details
app.get('/api/problems/:id', (req, res) => {
    const { id } = req.params;
    const problemDir = path.join(__dirname, '../problems', id);
    
    try {
        if (!fs.existsSync(problemDir)) return res.status(404).json({ error: 'Not found' });
        
        const response = {};
        
        const mdPath = path.join(problemDir, 'problem.md');
        if (fs.existsSync(mdPath)) {
            const content = fs.readFileSync(mdPath, 'utf8');
            response.description = content;
            const examples = extractExamples(content);
            response.sample1 = examples[0] || '';
            response.sample2 = examples[1] || '';
        }
        
        const solutionPath = path.join(problemDir, 'solution.cpp');
        if (fs.existsSync(solutionPath)) response.solution = fs.readFileSync(solutionPath, 'utf8');

        const solutionJavaPath = path.join(problemDir, 'Solution.java');
        if (fs.existsSync(solutionJavaPath)) response.solutionJava = fs.readFileSync(solutionJavaPath, 'utf8');
        
        const editorialPath = path.join(problemDir, 'editorial.md');
        if (fs.existsSync(editorialPath)) response.editorial = fs.readFileSync(editorialPath, 'utf8');
        
        res.json(response);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// Helper to compile code (C++ or Java)
function compileCode(codeFile, exeFile) {
    return new Promise((resolve) => {
        const compile = spawn('g++', [codeFile, '-o', exeFile]);
        let errOut = '';
        compile.stderr.on('data', data => errOut += data.toString());
        compile.on('close', code => resolve({ success: code === 0, error: errOut }));
    });
}

function compileJava(workDir) {
    return new Promise((resolve) => {
        const compile = spawn('javac', ['Solution.java'], { cwd: workDir });
        let errOut = '';
        compile.stderr.on('data', data => errOut += data.toString());
        compile.on('close', code => resolve({ success: code === 0, error: errOut }));
    });
}

// Prepare a submission: write code, compile, and return how to run it.
// Returns { success, error, runCmd, runArgs, cleanup }
async function prepareSubmission(code, language, tmpDir) {
    const uniqueId = Date.now().toString() + Math.floor(Math.random() * 100000);
    if (language === 'java') {
        const workDir = path.join(tmpDir, uniqueId);
        fs.mkdirSync(workDir, { recursive: true });
        fs.writeFileSync(path.join(workDir, 'Solution.java'), code);
        const comp = await compileJava(workDir);
        const cleanup = () => { try { fs.rmSync(workDir, { recursive: true, force: true }); } catch (e) {} };
        if (!comp.success) { cleanup(); return { success: false, error: comp.error }; }
        return { success: true, runCmd: 'java', runArgs: ['-Xss256m', '-cp', workDir, 'Solution'], cleanup };
    } else {
        const codeFile = path.join(tmpDir, `${uniqueId}.cpp`);
        const exeFile = path.join(tmpDir, `${uniqueId}.exe`);
        fs.writeFileSync(codeFile, code);
        const comp = await compileCode(codeFile, exeFile);
        const cleanup = () => { try { fs.unlinkSync(codeFile); fs.unlinkSync(exeFile); } catch (e) {} };
        if (!comp.success) { cleanup(); return { success: false, error: comp.error }; }
        return { success: true, runCmd: exeFile, runArgs: [], cleanup };
    }
}

// Helper to run code
function runExe(exeFile, input, args) {
    return new Promise((resolve) => {
        const run = spawn(exeFile, args || []);
        let out = '';
        let errOut = '';
        let isTimeout = false;
        
        const timer = setTimeout(() => {
            isTimeout = true;
            run.kill();
        }, 5000);
        
        if (input) {
            run.stdin.write(input);
            run.stdin.end();
        }
        
        run.stdout.on('data', data => out += data.toString());
        run.stderr.on('data', data => errOut += data.toString());
        
        run.on('close', code => {
            clearTimeout(timer);
            if (isTimeout) resolve({ status: 'Time Limit Exceeded', output: out });
            else if (code !== 0) resolve({ status: 'Runtime Error', output: errOut });
            else resolve({ status: 'Success', output: out });
        });
    });
}

// API to run code (custom input or sample input)
app.post('/api/run', async (req, res) => {
    const { problemId, code, input, language } = req.body;

    const tmpDir = path.join(__dirname, 'tmp');
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir);

    try {
        const sub = await prepareSubmission(code, language || 'cpp', tmpDir);
        if (!sub.success) {
            return res.json({ status: 'Compile Error', output: sub.error, expected: '' });
        }

        const userRun = await runExe(sub.runCmd, input, sub.runArgs);
        
        // Now run the expected solution if it was successful
        let expectedOutput = '';
        if (userRun.status === 'Success' && problemId) {
            const solExePath = path.join(__dirname, '../problems', problemId, 'solution.exe');
            if (fs.existsSync(solExePath)) {
                const solRun = await runExe(solExePath, input);
                if (solRun.status === 'Success') {
                    expectedOutput = solRun.output;
                }
            }
        }
        
        // Clean up
        sub.cleanup();

        res.json({ status: userRun.status, output: userRun.output, expected: expectedOutput });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// API to submit code (run against all test cases)
app.post('/api/submit', async (req, res) => {
    const { problemId, code } = req.body;
    if (!problemId) return res.status(400).json({ error: 'Missing problemId' });

    const testcasesDir = path.join(__dirname, '../problems', problemId, 'testcases');
    if (!fs.existsSync(testcasesDir)) {
        return res.json({ status: 'Error', message: 'No hidden test cases found for this problem.' });
    }

    const tmpDir = path.join(__dirname, 'tmp');
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir);

    try {
        const sub = await prepareSubmission(code, req.body.language || 'cpp', tmpDir);
        if (!sub.success) {
            return res.json({ status: 'Compile Error', message: sub.error });
        }

        // Gather all testcases
        const files = fs.readdirSync(testcasesDir);
        const inputs = files.filter(f => f.startsWith('input_')).sort((a,b) => {
            const na = parseInt(a.match(/\d+/)[0]);
            const nb = parseInt(b.match(/\d+/)[0]);
            return na - nb;
        });

        let passed = 0;
        let total = inputs.length;

        for (let i = 0; i < total; i++) {
            const inFileName = inputs[i];
            const idxMatch = inFileName.match(/\d+/);
            const idx = idxMatch ? idxMatch[0] : (i+1);
            const outFileName = `output_${idx}.txt`;
            
            const inPath = path.join(testcasesDir, inFileName);
            const outPath = path.join(testcasesDir, outFileName);

            const inputData = fs.readFileSync(inPath, 'utf8');
            const expectedData = fs.existsSync(outPath) ? fs.readFileSync(outPath, 'utf8') : '';

            const userRun = await runExe(sub.runCmd, inputData, sub.runArgs);

            if (userRun.status !== 'Success') {
                sub.cleanup();
                return res.json({ status: userRun.status, message: `Failed on Testcase ${idx}`, output: userRun.output, expected: expectedData });
            }

            // Trim and normalize line endings for comparison
            const normUser = userRun.output.replace(/\r\n/g, '\n').trim();
            const normExpected = expectedData.replace(/\r\n/g, '\n').trim();

            if (normUser !== normExpected) {
                sub.cleanup();
                return res.json({ status: 'Wrong Answer', message: `Failed on Testcase ${idx}`, output: userRun.output, expected: expectedData });
            }
            passed++;
        }

        // Clean up
        sub.cleanup();

        res.json({ status: 'Accepted', message: `Passed ${passed} / ${total} test cases! 🎉` });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.listen(PORT, () => {
    console.log(`Judge Server running at http://localhost:${PORT}`);
});
