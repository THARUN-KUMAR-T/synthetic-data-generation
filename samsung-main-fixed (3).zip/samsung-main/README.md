# Samsung Pro Coding Practice Portal

This is a local practice portal for Samsung Pro Test coding questions. It provides a sleek, dark-themed UI to browse problems, read editorials, write code, and execute it locally using `g++`.

## Prerequisites
- **Node.js** (v14 or higher)
- **g++** compiler installed and added to your system PATH

## Quick Start

1. Open your terminal and navigate to the `samsung/server` directory:
   ```bash
   cd samsung/server
   ```

2. Install the necessary dependencies (Express and CORS):
   ```bash
   npm install
   ```

3. Start the local judge server:
   ```bash
   npm start
   ```

4. Open your browser and go to:
   ```
   http://localhost:3000
   ```

## Features
- **16 Curated Problems**: Covering DP, Graphs, Trees, and Geometry.
- **In-browser Editor**: Integrated Monaco Editor (VS Code core) with syntax highlighting.
- **Local Code Execution**: Safely compiles and runs your C++ code against custom input.
- **Editorials & Verified Solutions**: Each problem comes with an approach explanation and a verified solution.

## Adding New Problems
To add a new problem, create a new folder inside the `problems` directory. The folder should contain:
- `problem.md`: The problem statement (must have `# [Title]` and `## Difficulty: [Diff]`).
- `solution.cpp`: The reference solution.
- `editorial.md`: The explanation of the approach.
