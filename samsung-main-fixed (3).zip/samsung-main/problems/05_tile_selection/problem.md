# Tile Selection (Minimize Maximum Difference)

## Difficulty: Medium
## Category: Binary Search, 2D Prefix Sum

## Problem Statement

You are given **N** tiles, each with a given **width** and **height**. You need to select **K** tiles such that the **maximum difference** between any two selected tiles is minimized.

The **difference** between two tiles (w₁, h₁) and (w₂, h₂) is defined as:
```
diff = max(|h₁ - h₂|, |w₁ - w₂|)
```

Find the minimum possible value of the maximum difference among all pairs of selected tiles.

## Input Format

```
N K
w[0] h[0]
w[1] h[1]
...
w[N-1] h[N-1]
```

## Output Format

A single integer — the minimum possible maximum difference.

## Constraints

- 1 ≤ K ≤ N ≤ 10^5
- 1 ≤ w[i], h[i] ≤ 400

## Examples

### Example 1

**Input:**
```
6 3
1 2
3 4
2 3
5 1
2 2
3 3
```

**Output:**
```
1
```

**Explanation:** Select tiles (2,3), (3,3), (2,2). Max diff = max(|3-2|, |3-2|) = 1.
