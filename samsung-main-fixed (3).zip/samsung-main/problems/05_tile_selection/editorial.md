# Tile Selection - Editorial

## Approach: Binary Search on Answer + 2D Prefix Sum

### Key Insight
Binary search on the answer `d`. For a given `d`, check if there's a `d×d` square in (width, height) space containing ≥ K tiles using 2D prefix sums.

### Algorithm
1. Build 2D frequency grid (since w, h ≤ 400).
2. Compute 2D prefix sums.
3. Binary search on `d` (0 to 400).
4. For each candidate `d`, slide a (d+1)×(d+1) window and check if any contains ≥ K tiles.

### Complexity
- **Time**: O(400² × log(400)) = O(~23M) — feasible
- **Space**: O(400²)
