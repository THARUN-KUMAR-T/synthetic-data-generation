import java.util.*;

public class Solution {

    // ---- fast input ----
    private static final java.io.DataInputStream in = new java.io.DataInputStream(new java.io.BufferedInputStream(System.in, 1 << 16));
    private static int readByte() throws java.io.IOException { return in.read(); }
    static long nextLong() throws java.io.IOException {
        int c = readByte(); while (c <= ' ') { if (c == -1) return Long.MIN_VALUE; c = readByte(); }
        boolean neg = false; if (c == '-') { neg = true; c = readByte(); }
        long x = 0; while (c > ' ') { x = x * 10 + (c - '0'); c = readByte(); }
        return neg ? -x : x;
    }
    static int nextInt() throws java.io.IOException { return (int) nextLong(); }
    static String nextToken() throws java.io.IOException {
        int c = readByte(); while (c <= ' ') { if (c == -1) return null; c = readByte(); }
        StringBuilder sb = new StringBuilder();
        while (c > ' ') { sb.append((char) c); c = readByte(); }
        return sb.toString();
    }

    public static void main(String[] args) throws Exception {
        int n = nextInt(), k = nextInt();
        int[][] f = new int[401][401];
        for (int i = 0; i < n; i++) f[nextInt()][nextInt()]++;
        // 2D prefix sum
        for (int i = 0; i < 401; i++)
            for (int j = 0; j < 401; j++) {
                if (i > 0) f[i][j] += f[i - 1][j];
                if (j > 0) f[i][j] += f[i][j - 1];
                if (i > 0 && j > 0) f[i][j] -= f[i - 1][j - 1];
            }
        // binary search the Chebyshev diameter d: some (d+1)x(d+1) box holds >= k tiles
        int lo = 0, hi = 400, ans = 400;
        while (lo <= hi) {
            int mid = (lo + hi) / 2;
            if (valid(f, mid, k)) { ans = mid; hi = mid - 1; } else lo = mid + 1;
        }
        System.out.println(ans);
    }

    static boolean valid(int[][] f, int d, int k) {
        for (int i = 0; i + d < 401; i++)
            for (int j = 0; j + d < 401; j++) {
                int cnt = f[i + d][j + d];
                if (i > 0) cnt -= f[i - 1][j + d];
                if (j > 0) cnt -= f[i + d][j - 1];
                if (i > 0 && j > 0) cnt += f[i - 1][j - 1];
                if (cnt >= k) return true;
            }
        return false;
    }
}
