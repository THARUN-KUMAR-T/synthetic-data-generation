import java.util.*;

public class Solution {

    // ---- fast input ----
    private static final java.io.DataInputStream in = new java.io.DataInputStream(new java.io.BufferedInputStream(System.in, 1 << 16));
    private static int readByte() throws java.io.IOException { return in.read(); }
    static long nextLong() throws java.io.IOException {
        int c = readByte(); while (c <= ' ') { if (c == -1) return Long.MIN_VALUE; c = readByte(); }
        boolean neg = false; if (c == '-') { neg = true; c = readByte(); }
        long x = 0; while (c > ' ') { x = x * 10 + (c - '0'); c = readByte(); }
        return neg ? -x : x;
    }
    static int nextInt() throws java.io.IOException { return (int) nextLong(); }
    static String nextToken() throws java.io.IOException {
        int c = readByte(); while (c <= ' ') { if (c == -1) return null; c = readByte(); }
        StringBuilder sb = new StringBuilder();
        while (c > ' ') { sb.append((char) c); c = readByte(); }
        return sb.toString();
    }

    public static void main(String[] args) throws Exception {
        StringBuilder out = new StringBuilder();
        int T = nextInt();
        while (T-- > 0) {
            int n = nextInt();
            long[] a = new long[n];
            for (int i = 0; i < n; i++) a[i] = nextLong();
            if (n < 2) { out.append(0).append('\n'); continue; }

            long[] lmax = new long[n], lmin = new long[n], rmax = new long[n], rmin = new long[n];
            long cur = a[0], best = a[0];
            lmax[0] = a[0];
            for (int i = 1; i < n; i++) { cur = Math.max(a[i], cur + a[i]); best = Math.max(best, cur); lmax[i] = best; }
            cur = a[0]; best = a[0]; lmin[0] = a[0];
            for (int i = 1; i < n; i++) { cur = Math.min(a[i], cur + a[i]); best = Math.min(best, cur); lmin[i] = best; }
            cur = a[n - 1]; best = a[n - 1]; rmax[n - 1] = a[n - 1];
            for (int i = n - 2; i >= 0; i--) { cur = Math.max(a[i], cur + a[i]); best = Math.max(best, cur); rmax[i] = best; }
            cur = a[n - 1]; best = a[n - 1]; rmin[n - 1] = a[n - 1];
            for (int i = n - 2; i >= 0; i--) { cur = Math.min(a[i], cur + a[i]); best = Math.min(best, cur); rmin[i] = best; }

            long ans = -1;
            for (int i = 0; i + 1 < n; i++) {
                ans = Math.max(ans, Math.abs(lmax[i] - rmin[i + 1]));
                ans = Math.max(ans, Math.abs(lmin[i] - rmax[i + 1]));
            }
            out.append(ans).append('\n');
        }
        System.out.print(out);
    }
}
