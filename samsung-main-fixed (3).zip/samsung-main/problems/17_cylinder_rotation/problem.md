# Cylinder Rotation (Safe Box)

## Difficulty: Medium
## Category: BFS / Matrix

Given an $M \times N$ matrix containing `0`s and `1`s, which represents a cylindrical lock (the left and right edges of each row are connected).
A `1` represents a hole or a target pattern. You can rotate each row independently to the left or right by one step, which costs 1 rotation.

Your goal is to align at least one `1` from every row into a single column. Find the **minimum total number of rotations** required to achieve this. If it's impossible to align them (i.e., there is a row with no `1`s), output `-1`.

### Input Format
- The first line contains the number of test cases $T$.
- For each test case, the first line contains $M$ and $N$ (the number of rows and columns).
- The next $M$ lines contain $N$ space-separated integers, each either `0` or `1`.

### Output Format
- For each test case, output the minimum total rotations required.
- If it's impossible, output `-1`.

### Constraints
- $1 \le M, N \le 1000$

**Input:**
```
1
6 5
0 1 0 0 1
0 0 0 1 0
0 1 0 0 0
0 0 0 0 1
0 0 1 0 0
1 0 0 0 0
```

**Output:**
```
6
```
