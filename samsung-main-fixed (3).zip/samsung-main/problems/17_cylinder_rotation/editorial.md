# Cylinder Rotation - Editorial

## Approach: Multi-source BFS

This problem asks us to find the minimum number of rotations to align at least one `1` from every row into the same column. Because the rows rotate independently and their left and right edges are connected, finding the shortest distance from any `1` to any cell in a row is equivalent to finding the shortest path on a circular array.

We can solve this efficiently using **Multi-source Breadth-First Search (BFS)** for each row independently.

### Step-by-Step Algorithm
1. **Initialize DP Matrix:** Create a `dp[M][N]` array initialized to infinity. `dp[i][j]` will store the minimum number of rotations needed to move a `1` in row `i` to column `j`.
2. **Multi-source BFS for each row:**
   - For a given row `i`, find all cells where `a[i][j] == 1`.
   - Set `dp[i][j] = 0` for these cells and push them into a queue `Q`.
   - Perform BFS: Pop a cell `cur`. Check its left neighbor `(cur - 1 + N) % N` and right neighbor `(cur + 1) % N`. 
   - If a neighbor's `dp` value is infinity, update it to `dp[i][cur] + 1` and push the neighbor into `Q`.
3. **Find the best column:**
   - After computing `dp` for all rows, iterate through each column `j` from `0` to `N-1`.
   - The total cost to align all `1`s into column `j` is the sum of `dp[i][j]` for all `i`.
   - Keep track of the minimum total cost across all columns.
4. **Edge Cases:** If for any column, `dp[i][j]` remains infinity (which means row `i` had no `1`s at all), it is impossible to align, so return `-1`.

### Complexity
- **Time Complexity:** $O(M \times N)$ since we do a BFS that visits every cell in each row exactly once, and then a final pass over the grid.
- **Space Complexity:** $O(M \times N)$ for the `dp` array and queue.
