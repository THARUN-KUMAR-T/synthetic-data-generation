#include <iostream>
#include <vector>
#include <queue>
#include <climits>
#include <algorithm>

using namespace std;

void solve() {
    int m, n;
    if (!(cin >> m >> n)) return;

    vector<vector<int>> a(m, vector<int>(n));
    vector<vector<int>> dp(m, vector<int>(n, INT_MAX));

    for (int i = 0; i < m; i++) {
        queue<int> q;
        for (int j = 0; j < n; j++) {
            cin >> a[i][j];
            if (a[i][j] == 1) {
                dp[i][j] = 0;
                q.push(j);
            }
        }

        while (!q.empty()) {
            int cur = q.front();
            q.pop();

            int left = (cur - 1 + n) % n;
            if (dp[i][left] == INT_MAX) {
                dp[i][left] = dp[i][cur] + 1;
                q.push(left);
            }

            int right = (cur + 1) % n;
            if (dp[i][right] == INT_MAX) {
                dp[i][right] = dp[i][cur] + 1;
                q.push(right);
            }
        }
    }

    int ans = INT_MAX;
    for (int j = 0; j < n; j++) {
        long long t = 0;
        bool possible = true;
        for (int i = 0; i < m; i++) {
            if (dp[i][j] == INT_MAX) {
                possible = false;
                break;
            }
            t += dp[i][j];
        }
        if (possible && t < ans) {
            ans = t;
        }
    }

    if (ans == INT_MAX) cout << -1 << "\n";
    else cout << ans << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    if (cin >> t) {
        while (t--) {
            solve();
        }
    }
    return 0;
}
