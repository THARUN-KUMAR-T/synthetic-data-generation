import java.util.*;

public class Solution {

    // ---- fast input ----
    private static final java.io.DataInputStream in = new java.io.DataInputStream(new java.io.BufferedInputStream(System.in, 1 << 16));
    private static int readByte() throws java.io.IOException { return in.read(); }
    static long nextLong() throws java.io.IOException {
        int c = readByte(); while (c <= ' ') { if (c == -1) return Long.MIN_VALUE; c = readByte(); }
        boolean neg = false; if (c == '-') { neg = true; c = readByte(); }
        long x = 0; while (c > ' ') { x = x * 10 + (c - '0'); c = readByte(); }
        return neg ? -x : x;
    }
    static int nextInt() throws java.io.IOException { return (int) nextLong(); }
    static String nextToken() throws java.io.IOException {
        int c = readByte(); while (c <= ' ') { if (c == -1) return null; c = readByte(); }
        StringBuilder sb = new StringBuilder();
        while (c > ' ') { sb.append((char) c); c = readByte(); }
        return sb.toString();
    }

    public static void main(String[] args) throws Exception {
        StringBuilder out = new StringBuilder();
        int t = nextInt();
        while (t-- > 0) {
            int m = nextInt(), n = nextInt();
            int[][] dp = new int[m][n];
            final int INF = Integer.MAX_VALUE;
            for (int i = 0; i < m; i++) {
                Arrays.fill(dp[i], INF);
                ArrayDeque<Integer> q = new ArrayDeque<>();
                for (int j = 0; j < n; j++) {
                    int x = nextInt();
                    if (x == 1) { dp[i][j] = 0; q.add(j); }
                }
                // multi-source ring BFS: nearest-1 circular distance per column
                while (!q.isEmpty()) {
                    int cur = q.poll();
                    int left = (cur - 1 + n) % n;
                    if (dp[i][left] == INF) { dp[i][left] = dp[i][cur] + 1; q.add(left); }
                    int right = (cur + 1) % n;
                    if (dp[i][right] == INF) { dp[i][right] = dp[i][cur] + 1; q.add(right); }
                }
            }
            long ans = Long.MAX_VALUE;
            for (int j = 0; j < n; j++) {
                long tt = 0; boolean ok = true;
                for (int i = 0; i < m; i++) {
                    if (dp[i][j] == Integer.MAX_VALUE) { ok = false; break; }
                    tt += dp[i][j];
                }
                if (ok && tt < ans) ans = tt;
            }
            out.append(ans == Long.MAX_VALUE ? -1 : ans).append('\n');
        }
        System.out.print(out);
    }
}
