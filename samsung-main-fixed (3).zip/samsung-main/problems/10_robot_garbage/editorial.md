# Robot Garbage - Editorial

## Approach: DP with Prefix Sums

### Key Insight
Decide where to deploy robots. At each non-zero position, either deploy a new robot (cost M) or continue with existing one (accumulating wait cost).

### Algorithm
1. Compute prefix sums for efficient range-cost calculations.
2. `dp[i]` = min cost to clean positions i..n-1, deploying first robot at i.
3. For each i, try all positions j > i as next deployment point.
4. Segment cost from deployment at d covering d..e-1 = Σ(k-d)×A[k].

### Complexity
- **Time**: O(N²) worst case
- **Space**: O(N)
