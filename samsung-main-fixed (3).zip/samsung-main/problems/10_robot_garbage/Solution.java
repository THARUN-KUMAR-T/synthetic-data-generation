import java.util.*;

public class Solution {

    // ---- fast input ----
    private static final java.io.DataInputStream in = new java.io.DataInputStream(new java.io.BufferedInputStream(System.in, 1 << 16));
    private static int readByte() throws java.io.IOException { return in.read(); }
    static long nextLong() throws java.io.IOException {
        int c = readByte(); while (c <= ' ') { if (c == -1) return Long.MIN_VALUE; c = readByte(); }
        boolean neg = false; if (c == '-') { neg = true; c = readByte(); }
        long x = 0; while (c > ' ') { x = x * 10 + (c - '0'); c = readByte(); }
        return neg ? -x : x;
    }
    static int nextInt() throws java.io.IOException { return (int) nextLong(); }
    static String nextToken() throws java.io.IOException {
        int c = readByte(); while (c <= ' ') { if (c == -1) return null; c = readByte(); }
        StringBuilder sb = new StringBuilder();
        while (c > ' ') { sb.append((char) c); c = readByte(); }
        return sb.toString();
    }

    public static void main(String[] args) throws Exception {
        StringBuilder out = new StringBuilder();
        int T = nextInt();
        while (T-- > 0) {
            int n = nextInt();
            long m = nextLong();
            long[] A = new long[n];
            for (int i = 0; i < n; i++) A[i] = nextLong();

            int start = 0;
            while (start < n && A[start] == 0) start++;
            if (start == n) { out.append(0).append('\n'); continue; }

            // prefix sums for O(1) segment cost: sum (k-d)*A[k] over [d, e)
            long[] prefix = new long[n + 1], wprefix = new long[n + 1];
            for (int i = 0; i < n; i++) {
                prefix[i + 1] = prefix[i] + A[i];
                wprefix[i + 1] = wprefix[i] + (long) i * A[i];
            }

            long[] dp = new long[n + 1];
            Arrays.fill(dp, (long) 1e18);
            dp[n] = 0;
            for (int i = n - 1; i >= start; i--) {
                if (A[i] == 0 && i > start) { dp[i] = dp[i + 1]; continue; }
                long best = m + seg(prefix, wprefix, i, n); // this robot finishes alone
                for (int j = i + 1; j < n; j++)
                    if (A[j] > 0) best = Math.min(best, m + seg(prefix, wprefix, i, j) + dp[j]);
                dp[i] = best;
            }
            out.append(dp[start]).append('\n');
        }
        System.out.print(out);
    }

    static long seg(long[] p, long[] w, int d, int e) {
        return (w[e] - w[d]) - (long) d * (p[e] - p[d]);
    }
}
