# Robot Garbage Cleaning

## Difficulty: Medium
## Category: Dynamic Programming

## Problem Statement

You have an array of **N** cells where each cell `i` contains `A[i]` units of garbage.

You can deploy robots to clean the garbage:
- Deploying a robot at any index costs **M**.
- A robot cleans garbage at its current index and can only move to index `i+1`.
- At any moment, the cost includes the **sum of all remaining uncleaned garbage** (carrying cost per time step).

When a robot is at position `i` and was deployed at position `d`, the cost of cleaning position `i` is `(i - d) × A[i]` (the garbage waited `(i-d)` time steps).

Find the **minimum total cost** to clean all garbage.

## Input Format

```
T                       (number of test cases)
N M                     (array size, robot deployment cost)
A[0] A[1] ... A[N-1]   (garbage at each cell)
```

## Output Format

For each test case, print the minimum cost.

## Constraints

- 1 ≤ T ≤ 10
- 1 ≤ N ≤ 10^5
- 1 ≤ M ≤ 10^9
- 0 ≤ A[i] ≤ 10^9

## Examples

### Example 1

**Input:**
```
1
5 2
3 1 4 1 5
```

**Output:**
```
8
```

**Explanation:** Deploy robots strategically to minimize the total of deployment costs + waiting costs.
