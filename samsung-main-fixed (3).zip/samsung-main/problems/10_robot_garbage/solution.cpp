#include <bits/stdc++.h>
using namespace std;
using ll = long long;

int main() {
    int T;
    cin >> T;
    while (T--) {
        int n;
        ll m;
        cin >> n >> m;
        vector<ll> A(n);
        for (int i = 0; i < n; i++) cin >> A[i];

        // dp[i] = min cost to clean all garbage from index i to n-1
        // At each position, either:
        //   1. Deploy a new robot here (cost M + continue)
        //   2. Use existing robot (cost = (i - last_deploy) * A[i] + continue)
        // We use dp[i] = min cost to handle positions i..n-1,
        // given last robot deployed at position 'last'

        // Find first non-zero
        int start = 0;
        while (start < n && A[start] == 0) start++;
        if (start == n) {
            cout << 0 << "\n";
            continue;
        }

        // dp_table[i] = min cost from position i onwards, with a robot currently deployed at i
        vector<ll> dp(n + 1, 0);

        // Process backwards: dp[i] = min over all j > i where we place next robot
        // Cost of current robot deployed at i covering i..j-1:
        // sum of (k-i)*A[k] for k=i..j-1, then M + dp[j]

        // Forward DP: f[i] = min cost to clean 0..i, with last robot deployed at position 'last'
        // O(n^2) might be needed, but let's use the recursive approach with memoization

        // Simple O(n^2) DP
        // cost[i] = min cost to clean everything, given we must deploy first robot at position i or later
        // dp[i] = M + sum of (k-i)*A[k] for k from i to next_deploy-1, + dp[next_deploy]

        // Let prefix[i] = A[0] + ... + A[i-1]
        // Let wprefix[i] = 0*A[0] + 1*A[1] + ... + (i-1)*A[i-1]

        vector<ll> prefix(n + 1, 0), wprefix(n + 1, 0);
        for (int i = 0; i < n; i++) {
            prefix[i + 1] = prefix[i] + A[i];
            wprefix[i + 1] = wprefix[i] + (ll)i * A[i];
        }

        // Cost of robot at position d covering d..e-1:
        // sum_{k=d}^{e-1} (k-d)*A[k] = (wprefix[e] - wprefix[d]) - d*(prefix[e] - prefix[d])

        auto segCost = [&](int d, int e) -> ll {
            return (wprefix[e] - wprefix[d]) - (ll)d * (prefix[e] - prefix[d]);
        };

        // dp[i] = min cost to clean i..n-1 with a new robot at i
        // dp[i] = M + min over j in [i+1..n] of { segCost(i, j) + dp[j] }
        // dp[n] = 0 (nothing to clean)
        // Also dp[i] = M + segCost(i, n) if we don't deploy another robot

        vector<ll> dpArr(n + 1, 1e18);
        dpArr[n] = 0;

        for (int i = n - 1; i >= start; i--) {
            if (A[i] == 0 && i > start) {
                dpArr[i] = dpArr[i + 1]; // skip zeros
                continue;
            }
            // Deploy robot at i
            ll best = m + segCost(i, n); // cover everything from i to end
            for (int j = i + 1; j < n; j++) {
                if (A[j] > 0) {
                    ll cost = m + segCost(i, j) + dpArr[j];
                    best = min(best, cost);
                }
            }
            dpArr[i] = best;
        }

        cout << dpArr[start] << "\n";
    }
    return 0;
}
