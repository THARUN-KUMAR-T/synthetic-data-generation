import java.util.*;

public class Solution {

    // ---- fast input ----
    private static final java.io.DataInputStream in = new java.io.DataInputStream(new java.io.BufferedInputStream(System.in, 1 << 16));
    private static int readByte() throws java.io.IOException { return in.read(); }
    static long nextLong() throws java.io.IOException {
        int c = readByte(); while (c <= ' ') { if (c == -1) return Long.MIN_VALUE; c = readByte(); }
        boolean neg = false; if (c == '-') { neg = true; c = readByte(); }
        long x = 0; while (c > ' ') { x = x * 10 + (c - '0'); c = readByte(); }
        return neg ? -x : x;
    }
    static int nextInt() throws java.io.IOException { return (int) nextLong(); }
    static String nextToken() throws java.io.IOException {
        int c = readByte(); while (c <= ' ') { if (c == -1) return null; c = readByte(); }
        StringBuilder sb = new StringBuilder();
        while (c > ' ') { sb.append((char) c); c = readByte(); }
        return sb.toString();
    }

    static final long INF = (long) 1e15;
    static StringBuilder out = new StringBuilder();

    public static void main(String[] args) throws Exception {
        int t = nextInt();
        while (t-- > 0) solve();
        System.out.print(out);
    }

    static void solve() throws Exception {
        int h = nextInt(), w = nextInt(), c = nextInt();
        int[][] grid = new int[h][w];
        int gr = -1, gc = -1, ar = -1, ac = -1;
        ArrayList<int[]> wh = new ArrayList<>();
        for (int r = 0; r < h; r++)
            for (int ci = 0; ci < w; ci++) {
                grid[r][ci] = nextInt();
                if (grid[r][ci] == 2) { gr = r; gc = ci; }
                else if (grid[r][ci] == 3) wh.add(new int[]{r, ci});
                else if (grid[r][ci] == 4) { ar = r; ac = ci; }
            }
        int W = wh.size();
        if (W == 0 || gr == -1 || ar == -1) { out.append(0).append('\n'); return; }

        // Layer 1: BFS distances between the K = W+2 key points (trees block)
        int K = W + 2;
        long[][] dist = new long[K][K];
        for (long[] row : dist) Arrays.fill(row, INF);
        int[] dr = {-1, 1, 0, 0}, dc = {0, 0, -1, 1};
        for (int node = 0; node < K; node++) {
            int sr = node == 0 ? gr : node <= W ? wh.get(node - 1)[0] : ar;
            int sc = node == 0 ? gc : node <= W ? wh.get(node - 1)[1] : ac;
            long[][] d = new long[h][w];
            for (long[] row : d) Arrays.fill(row, INF);
            ArrayDeque<int[]> q = new ArrayDeque<>();
            q.add(new int[]{sr, sc}); d[sr][sc] = 0;
            while (!q.isEmpty()) {
                int[] p = q.poll();
                for (int i = 0; i < 4; i++) {
                    int nr = p[0] + dr[i], nc = p[1] + dc[i];
                    if (nr >= 0 && nr < h && nc >= 0 && nc < w && grid[nr][nc] != 1 && d[nr][nc] == INF) {
                        d[nr][nc] = d[p[0]][p[1]] + 1;
                        q.add(new int[]{nr, nc});
                    }
                }
            }
            dist[node][0] = d[gr][gc];
            for (int i = 0; i < W; i++) dist[node][i + 1] = d[wh.get(i)[0]][wh.get(i)[1]];
            dist[node][W + 1] = d[ar][ac];
        }

        // Layer 2: single-trip TSP bitmask DP; carrying sz goods costs dist*(sz+1) per segment
        int FULL = 1 << W;
        long[][][] dpTrip = new long[2][FULL][W];
        for (long[][] a : dpTrip) for (long[] b : a) Arrays.fill(b, INF);
        for (int i = 0; i < W; i++) {
            if (dist[0][i + 1] != INF) dpTrip[0][1 << i][i] = dist[0][i + 1];
            if (dist[W + 1][i + 1] != INF) dpTrip[1][1 << i][i] = dist[W + 1][i + 1];
        }
        for (int mask = 1; mask < FULL; mask++) {
            int sz = Integer.bitCount(mask);
            for (int last = 0; last < W; last++) {
                if ((mask & (1 << last)) == 0) continue;
                for (int next = 0; next < W; next++) {
                    if ((mask & (1 << next)) != 0 || dist[last + 1][next + 1] == INF) continue;
                    int nm = mask | (1 << next);
                    long seg = dist[last + 1][next + 1] * (sz + 1);
                    for (int s = 0; s < 2; s++)
                        if (dpTrip[s][mask][last] != INF)
                            dpTrip[s][nm][next] = Math.min(dpTrip[s][nm][next], dpTrip[s][mask][last] + seg);
                }
            }
        }

        // close each trip with the drop-off leg to the airport
        long[] tripG = new long[FULL], tripA = new long[FULL];
        Arrays.fill(tripG, INF); Arrays.fill(tripA, INF);
        tripG[0] = 0; tripA[0] = 0;
        for (int mask = 1; mask < FULL; mask++) {
            int sz = Integer.bitCount(mask);
            for (int last = 0; last < W; last++) {
                if ((mask & (1 << last)) == 0 || dist[last + 1][W + 1] == INF) continue;
                long drop = dist[last + 1][W + 1] * (sz + 1);
                if (dpTrip[0][mask][last] != INF) tripG[mask] = Math.min(tripG[mask], dpTrip[0][mask][last] + drop);
                if (dpTrip[1][mask][last] != INF) tripA[mask] = Math.min(tripA[mask], dpTrip[1][mask][last] + drop);
            }
        }

        // Layer 3: submask partition into trips (first from garage, rest from airport)
        long[] dpA = new long[FULL], dpG = new long[FULL];
        Arrays.fill(dpA, INF); Arrays.fill(dpG, INF);
        dpA[0] = 0; dpG[0] = 0;
        for (int mask = 1; mask < FULL; mask++)
            for (int sub = mask; sub > 0; sub = (sub - 1) & mask)
                if (tripA[sub] != INF && dpA[mask ^ sub] != INF)
                    dpA[mask] = Math.min(dpA[mask], tripA[sub] + dpA[mask ^ sub]);
        for (int mask = 1; mask < FULL; mask++)
            for (int sub = mask; sub > 0; sub = (sub - 1) & mask)
                if (tripG[sub] != INF && dpA[mask ^ sub] != INF)
                    dpG[mask] = Math.min(dpG[mask], tripG[sub] + dpA[mask ^ sub]);

        int maxGoods = 0;
        for (int mask = 0; mask < FULL; mask++)
            if (dpG[mask] <= c) maxGoods = Math.max(maxGoods, Integer.bitCount(mask));
        out.append(maxGoods).append('\n');
    }
}
