#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

const long long INF = 1e15;

int popcount(int n) {
    int count = 0;
    while (n) { n &= (n - 1); count++; }
    return count;
}

void solve() {
    int h, w, c;
    cin >> h >> w >> c;
    vector<vector<int>> grid(h, vector<int>(w));
    pair<int, int> garage = {-1, -1}, airport = {-1, -1};
    vector<pair<int, int>> warehouses;

    for (int r = 0; r < h; r++) {
        for (int ci = 0; ci < w; ci++) {
            cin >> grid[r][ci];
            if (grid[r][ci] == 2) garage = {r, ci};
            else if (grid[r][ci] == 3) warehouses.push_back({r, ci});
            else if (grid[r][ci] == 4) airport = {r, ci};
        }
    }

    int W = warehouses.size();
    if (W == 0 || garage.first == -1 || airport.first == -1) {
        cout << 0 << "\n";
        return;
    }

    // K = number of key points: 0=Garage, 1..W=Warehouses, W+1=Airport
    int K = W + 2;
    vector<vector<long long>> dist(K, vector<long long>(K, INF));
    int dr[] = {-1, 1, 0, 0}, dc[] = {0, 0, -1, 1};

    auto bfs_from = [&](int node, pair<int, int> start) {
        vector<vector<long long>> d(h, vector<long long>(w, INF));
        queue<pair<int, int>> q;
        q.push(start);
        d[start.first][start.second] = 0;
        while (!q.empty()) {
            auto p = q.front(); q.pop();
            int r = p.first;
            int cc = p.second;
            for (int i = 0; i < 4; i++) {
                int nr = r + dr[i], nc = cc + dc[i];
                if (nr >= 0 && nr < h && nc >= 0 && nc < w && grid[nr][nc] != 1 && d[nr][nc] == INF) {
                    d[nr][nc] = d[r][cc] + 1;
                    q.push(make_pair(nr, nc));
                }
            }
        }
        dist[node][0] = d[garage.first][garage.second];
        for (int i = 0; i < W; i++)
            dist[node][i + 1] = d[warehouses[i].first][warehouses[i].second];
        dist[node][W + 1] = d[airport.first][airport.second];
    };

    bfs_from(0, garage);
    for (int i = 0; i < W; i++) bfs_from(i + 1, warehouses[i]);
    bfs_from(W + 1, airport);

    // Bitmask DP for trip cost
    // dp_trip[start_type][mask][last_warehouse] = min cost of collecting warehouses in mask
    // start_type: 0=from Garage, 1=from Airport
    vector<vector<vector<long long>>> dp_trip(2, vector<vector<long long>>(1 << W, vector<long long>(W, INF)));

    for (int i = 0; i < W; i++) {
        if (dist[0][i + 1] != INF) dp_trip[0][1 << i][i] = dist[0][i + 1] * 1;
        if (dist[W + 1][i + 1] != INF) dp_trip[1][1 << i][i] = dist[W + 1][i + 1] * 1;
    }

    for (int mask = 1; mask < (1 << W); mask++) {
        int sz = popcount(mask);
        for (int last = 0; last < W; last++) {
            if (!(mask & (1 << last))) continue;
            for (int next = 0; next < W; next++) {
                if (mask & (1 << next)) continue;
                if (dist[last + 1][next + 1] == INF) continue;
                int new_mask = mask | (1 << next);
                long long seg_cost = dist[last + 1][next + 1] * (sz + 1);
                for (int s = 0; s < 2; s++) {
                    if (dp_trip[s][mask][last] != INF) {
                        dp_trip[s][new_mask][next] = min(dp_trip[s][new_mask][next],
                            dp_trip[s][mask][last] + seg_cost);
                    }
                }
            }
        }
    }

    // Cost to deliver a subset in a single trip (ending at airport)
    vector<long long> trip_G(1 << W, INF), trip_A(1 << W, INF);
    trip_G[0] = 0;
    trip_A[0] = 0;

    for (int mask = 1; mask < (1 << W); mask++) {
        int sz = popcount(mask);
        for (int last = 0; last < W; last++) {
            if (!(mask & (1 << last))) continue;
            if (dist[last + 1][W + 1] == INF) continue;
            long long drop = dist[last + 1][W + 1] * (sz + 1);
            if (dp_trip[0][mask][last] != INF)
                trip_G[mask] = min(trip_G[mask], dp_trip[0][mask][last] + drop);
            if (dp_trip[1][mask][last] != INF)
                trip_A[mask] = min(trip_A[mask], dp_trip[1][mask][last] + drop);
        }
    }

    // Multi-trip DP: partition warehouses into trips
    vector<long long> dp_A(1 << W, INF);
    dp_A[0] = 0;
    for (int mask = 1; mask < (1 << W); mask++) {
        for (int sub = mask; sub > 0; sub = (sub - 1) & mask) {
            if (trip_A[sub] != INF && dp_A[mask ^ sub] != INF)
                dp_A[mask] = min(dp_A[mask], trip_A[sub] + dp_A[mask ^ sub]);
        }
    }

    vector<long long> dp_G(1 << W, INF);
    dp_G[0] = 0;
    for (int mask = 1; mask < (1 << W); mask++) {
        for (int sub = mask; sub > 0; sub = (sub - 1) & mask) {
            if (trip_G[sub] != INF && dp_A[mask ^ sub] != INF)
                dp_G[mask] = min(dp_G[mask], trip_G[sub] + dp_A[mask ^ sub]);
        }
    }

    int max_goods = 0;
    for (int mask = 0; mask < (1 << W); mask++) {
        if (dp_G[mask] <= c) {
            max_goods = max(max_goods, popcount(mask));
        }
    }
    cout << max_goods << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin >> t;
    while (t--) solve();
    return 0;
}
