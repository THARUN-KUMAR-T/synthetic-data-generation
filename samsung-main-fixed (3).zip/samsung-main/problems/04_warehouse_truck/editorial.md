# Warehouse Truck - Editorial

## Approach: BFS + Bitmask DP (TSP-like)

### Key Insight
With at most 13 warehouses, we can use bitmask DP (similar to Travelling Salesman Problem). The truck can make multiple trips, each starting from garage/airport.

### Algorithm
1. **BFS from each key point** (garage, each warehouse, airport) to compute pairwise shortest distances.
2. **Bitmask DP for single trip**: `dp[mask][last]` = min cost to collect warehouses in `mask`, ending at `last`.
3. **Trip cost**: Add delivery cost to airport from the last warehouse. Cost per step = (goods_carried + 1).
4. **Multi-trip DP**: Partition all warehouses into subsets (trips), minimize total cost.
5. **Answer**: Maximum popcount(mask) where total cost ≤ C.

### Complexity
- **Time**: O(K² × H × W) for BFS + O(3^W × W) for subset DP
- **Space**: O(2^W × W) for DP tables
- With W ≤ 13: 3^13 ≈ 1.6M, feasible.
