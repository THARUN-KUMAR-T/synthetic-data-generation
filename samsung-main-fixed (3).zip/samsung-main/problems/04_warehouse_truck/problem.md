# Warehouse Truck (Maximum Goods)

## Difficulty: Hard
## Category: BFS, Bitmask DP, Shortest Path

## Problem Statement

You are given a 2D grid of size **H × W** representing a city. Each cell has a value:
- **0** → Road (passable)
- **1** → Tree (blocked, cannot pass)
- **2** → Garage (truck starting position)
- **3** → Warehouse (can pick up one good)
- **4** → Airport (unload destination)

A truck starts at the Garage. Its task is to visit warehouses, pick up goods, and deliver them to the Airport.

**Cost model**: Moving one block costs `(1 + number of goods currently carried)`. So:
- Empty truck: 1 per block
- 1 good: 2 per block  
- k goods: (k+1) per block

The truck can visit multiple warehouses before going to the airport. At any warehouse, it may choose to pick up the good or not. It can make multiple trips (Garage → warehouses → Airport → repeat from Airport).

Find the **maximum number of goods** that can be delivered to the airport with total cost ≤ **C**.

## Input Format

```
T                       (number of test cases)
H W C                   (grid height, width, max cost)
grid[0][0] ... grid[0][W-1]
...
grid[H-1][0] ... grid[H-1][W-1]
```

## Output Format

For each test case, print the maximum number of goods deliverable.

## Constraints

- 1 ≤ T ≤ 50
- 2 ≤ H, W ≤ 40
- 5 ≤ C ≤ 2000
- At most **13** warehouses
- Exactly one garage (2) and one airport (4)

## Examples

### Example 1

**Input:**
```
1
6 6 20
2 0 0 0 0 0
0 1 1 1 0 0
0 0 3 0 3 0
0 0 0 0 0 0
1 0 3 0 0 0
0 0 0 0 0 4
```

**Explanation:**
3 warehouses at positions (2,2), (2,4), (4,2). Garage at (0,0), Airport at (5,5).
Optimal plan: Garage → (2,2) [4 blocks × 1 = 4] → pick up → (2,4) [2 blocks × 2 = 4] → pick up → Airport [4 blocks × 3 = 12]. Total = 20 ≤ 20, delivering 2 goods. Any plan delivering all 3 goods exceeds the budget.

**Output:**
```
2
```
