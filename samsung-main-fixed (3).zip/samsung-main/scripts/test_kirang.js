const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const kirangDir = path.join(__dirname, '../../sharma-fork');
const problemsDir = path.join(__dirname, '../problems');

const mapping = {
    '01_points_on_path': '1_segments.cpp',
    '02_minimum_days': '2_days.cpp',
    '03_red_blue_necklace': '3_RB.cpp',
    '04_warehouse_truck': '4_1_warehouse.cpp',
    '05_tile_selection': '4_2_tiles.cpp',
    '06_stone_removal': '4_3_stones.cpp',
    '07_string_merge': '5_1_strings.cpp',
    '08_optimal_d_score': '5_2_scores.cpp',
    '09_car_parking': '6_1_cars.cpp',
    '10_robot_garbage': '7_1_robot.cpp',
    '11_digit_sum': '7_2_digit_sum.cpp',
    '12_apple_game': 'apples.cpp',
    '13_logging_trees': 'logging_trees.cpp',
    '14_min_cost_tree': 'min_cost.cpp',
    '15_min_subset_diff': 'min_subset_diff.cpp',
    '16_soldiers_tree': 'soldiers.cpp'
};

const results = {};

for (const folder of Object.keys(mapping)) {
    console.log(`\nTesting ${folder}...`);
    const kirangFile = mapping[folder];
    const sourcePath = path.join(kirangDir, kirangFile);
    
    if (!fs.existsSync(sourcePath)) {
        console.log(`❌ Source not found: ${kirangFile}`);
        continue;
    }
    
    const exePath = path.join(__dirname, 'temp_kirang.exe');
    
    // Compile
    const compile = spawnSync('g++', [sourcePath, '-std=c++17', '-o', exePath]);
    if (compile.status !== 0) {
        console.log(`❌ Compile Error in ${kirangFile}`);
        results[folder] = 'Compile Error';
        continue;
    }
    
    const testcasesDir = path.join(problemsDir, folder, 'testcases');
    if (!fs.existsSync(testcasesDir)) {
        console.log(`❌ Testcases not found for ${folder}`);
        continue;
    }
    
    let passed = 0;
    let failed = 0;
    let tle = 0;
    let re = 0;
    
    const files = fs.readdirSync(testcasesDir).filter(f => f.startsWith('input_'));
    const total = files.length;
    
    for (const file of files) {
        const inPath = path.join(testcasesDir, file);
        const outPath = path.join(testcasesDir, file.replace('input_', 'output_'));
        
        const inputData = fs.readFileSync(inPath, 'utf8');
        const expectedData = fs.readFileSync(outPath, 'utf8');
        
        const run = spawnSync(exePath, { input: inputData, timeout: 3000 });
        
        if (run.error && run.error.code === 'ETIMEDOUT') {
            tle++;
        } else if (run.status !== 0) {
            re++;
        } else {
            const actual = run.stdout.toString().replace(/\r\n/g, '\n').trim();
            const expected = expectedData.replace(/\r\n/g, '\n').trim();
            if (actual === expected) {
                passed++;
            } else {
                failed++;
            }
        }
    }
    
    console.log(`✅ Passed: ${passed} | ❌ Failed: ${failed} | ⏰ TLE: ${tle} | 💥 RE: ${re}`);
    results[folder] = { passed, failed, tle, re, total };
    
    // Clean up
    try { fs.unlinkSync(exePath); } catch(e){}
}

console.log('\n================ SUMMARY ================');
for (const [folder, res] of Object.entries(results)) {
    if (typeof res === 'string') {
        console.log(`${folder.padEnd(25)}: ${res}`);
    } else {
        const status = res.passed === res.total ? 'ALL PASSED' : 'FAILED';
        console.log(`${folder.padEnd(25)}: ${status} (Pass: ${res.passed}, Fail: ${res.failed}, TLE: ${res.tle}, RE: ${res.re})`);
    }
}
