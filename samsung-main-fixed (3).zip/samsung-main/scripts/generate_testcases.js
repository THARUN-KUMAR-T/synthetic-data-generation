const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const problemsDir = path.join(__dirname, '../problems');

// Utility to get random integer between min and max (inclusive)
function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomArray(size, min, max) {
    const arr = [];
    for (let i = 0; i < size; i++) arr.push(randomInt(min, max));
    return arr;
}

// Generators for each problem based on their constraints
const generators = {
    '01_points_on_path': () => {
        let T = 1;
        let out = `${T}\n`;
        let N = randomInt(5, 50);
        let M = randomInt(2, 20);
        out += `${N} ${M}\n`;
        out += randomArray(N, -100, 100).join(' ') + '\n';
        out += randomArray(N, -100, 100).join(' ') + '\n';
        // Generate valid path (alternating X and Y changes)
        let px = [randomInt(-100, 100)], py = [randomInt(-100, 100)];
        for (let i = 1; i < M; i++) {
            if (i % 2 === 1) {
                px.push(px[i-1]);
                py.push(randomInt(-100, 100));
            } else {
                px.push(randomInt(-100, 100));
                py.push(py[i-1]);
            }
        }
        out += px.join(' ') + '\n';
        out += py.join(' ') + '\n';
        return out;
    },
    '02_minimum_days': () => {
        let T = 1;
        let out = `${T}\n`;
        let N = randomInt(5, 20);
        let K = randomInt(10, 1000);
        out += `${N} ${K}\n`;
        for (let i = 0; i < N; i++) {
            out += `${randomInt(0, 100)} ${randomInt(0, 50)}\n`;
        }
        return out;
    },
    '03_red_blue_necklace': () => {
        let N = randomInt(10, 1000);
        let s = '';
        for (let i = 0; i < N; i++) s += Math.random() > 0.5 ? 'R' : 'B';
        return s + '\n';
    },
    '04_warehouse_truck': () => {
        let T = 1;
        let out = `${T}\n`;
        let H = randomInt(5, 10);
        let W = randomInt(5, 10);
        let C = randomInt(10, 100);
        out += `${H} ${W} ${C}\n`;
        
        let grid = Array(H).fill(0).map(() => Array(W).fill(0));
        // Place Garage (2) and Airport (4)
        grid[randomInt(0, H-1)][randomInt(0, W-1)] = 2;
        let ax, ay;
        do { ax = randomInt(0, H-1); ay = randomInt(0, W-1); } while (grid[ax][ay] !== 0);
        grid[ax][ay] = 4;
        
        // Place Warehouses (3) - max 10
        let wCount = randomInt(1, 10);
        for (let i = 0; i < wCount; i++) {
            let wx, wy;
            do { wx = randomInt(0, H-1); wy = randomInt(0, W-1); } while (grid[wx][wy] !== 0);
            grid[wx][wy] = 3;
        }
        // Place some trees (1)
        for (let i = 0; i < (H*W)/4; i++) {
            let tx = randomInt(0, H-1), ty = randomInt(0, W-1);
            if (grid[tx][ty] === 0) grid[tx][ty] = 1;
        }
        for (let r = 0; r < H; r++) out += grid[r].join(' ') + '\n';
        return out;
    },
    '05_tile_selection': () => {
        let N = randomInt(10, 1000);
        let K = randomInt(1, N);
        let out = `${N} ${K}\n`;
        for (let i = 0; i < N; i++) out += `${randomInt(1, 400)} ${randomInt(1, 400)}\n`;
        return out;
    },
    '06_stone_removal': () => {
        let N = randomInt(5, 1000);
        let out = `${N}\n`;
        out += randomArray(N, 0, 1000).join(' ') + '\n';
        out += randomArray(N, 0, 1000).join(' ') + '\n';
        return out;
    },
    '07_string_merge': () => {
        let T = 1;
        let out = `${T}\n`;
        let N = randomInt(5, 500);
        out += `${N}\n`;
        let arr = [];
        for (let i = 0; i < N; i++) {
            let len = randomInt(1, 5);
            let s = '';
            for (let j = 0; j < len; j++) s += randomInt(1, 9);
            arr.push(s);
        }
        out += arr.join(' ') + '\n';
        return out;
    },
    '08_optimal_d_score': () => {
        let T = 1;
        let out = `${T}\n`;
        let N = randomInt(10, 1000);
        let M = randomInt(10, 1000);
        out += `${N} ${M}\n`;
        out += randomArray(N, 1, 10000).join(' ') + '\n';
        out += randomArray(M, 1, 10000).join(' ') + '\n';
        return out;
    },
    '09_car_parking': () => {
        let T = 1;
        let out = `${T}\n`;
        let N = randomInt(2, 50);
        let M = 1000;
        out += `${N} ${M}\n`;
        out += `${randomInt(0, 100)} ${randomInt(0, 100)}\n`;
        // All cars must have same parity distance to dest to be solvable
        let cx = randomInt(0, 100), cy = randomInt(0, 100);
        for(let i=0; i<N; i++) {
             // to keep parity consistent, let's just make it completely random
             // Some will be -1, which is fine to test
             out += `${randomInt(0, 100)} ${randomInt(0, 100)}\n`;
        }
        return out;
    },
    '10_robot_garbage': () => {
        let T = 1;
        let out = `${T}\n`;
        let N = randomInt(10, 1000);
        let M = randomInt(10, 1000);
        out += `${N} ${M}\n`;
        out += randomArray(N, 0, 100).join(' ') + '\n';
        return out;
    },
    '11_digit_sum': () => {
        // A is large string, S is sum
        let len = randomInt(1, 100);
        let A = '';
        A += randomInt(1, 9);
        for (let i=1; i<len; i++) A += randomInt(0, 9);
        let S = randomInt(1, 900);
        return `${A} ${S}\n`;
    },
    '12_apple_game': () => {
        let N = randomInt(5, 10);
        let M = randomInt(2, 5);
        let out = `${N} ${M}\n`;
        let grid = Array(N).fill(0).map(() => Array(N).fill(0));
        // Put apples
        for(let i=1; i<=M; i++) {
            let r, c;
            do { r = randomInt(0, N-1); c = randomInt(0, N-1); } while (grid[r][c] !== 0 || (r===0 && c===0));
            grid[r][c] = i;
        }
        // Put traps
        for(let i=0; i<(N*N)/4; i++) {
            let r = randomInt(0, N-1), c = randomInt(0, N-1);
            if (grid[r][c] === 0 && !(r===0 && c===0)) grid[r][c] = -1;
        }
        for (let r=0; r<N; r++) out += grid[r].join(' ') + '\n';
        return out;
    },
    '13_logging_trees': () => {
        let N = randomInt(5, 50);
        let out = `${N}\n`;
        for (let i=1; i<N; i++) {
            // L R
            let l = Math.random() > 0.5 ? randomInt(1, 10) : 0;
            let r = Math.random() > 0.5 ? randomInt(1, 10) : 0;
            out += `${l} ${r}\n`;
        }
        return out;
    },
    '14_min_cost_tree': () => {
        let N = randomInt(5, 1000);
        let out = `${N}\n`;
        out += randomArray(N, 1, 1000).join(' ') + '\n';
        for (let i=2; i<=N; i++) {
            out += `${randomInt(1, i-1)} ${i}\n`;
        }
        return out;
    },
    '15_min_subset_diff': () => {
        let T = 1;
        let out = `${T}\n`;
        let N = randomInt(5, 40);
        out += `${N}\n`;
        out += randomArray(N, 1, 1000).join(' ') + '\n';
        return out;
    },
    '16_soldiers_tree': () => {
        let N = randomInt(5, 500);
        let out = `${N}\n`;
        out += `-1 ${randomInt(1, 100)}\n`;
        for(let i=1; i<N; i++) {
            out += `${randomInt(0, i-1)} ${randomInt(1, 100)}\n`;
        }
        return out;
    },
    '17_cylinder_rotation': () => {
        let T = 1;
        let out = `${T}\n`;
        let M = randomInt(5, 100);
        let N = randomInt(5, 100);
        out += `${M} ${N}\n`;
        for (let i = 0; i < M; i++) {
            let row = Array(N).fill(0);
            // Guarantee at least one 1 per row for some cases, or no 1s to test impossible
            let ones = Math.random() > 0.05 ? randomInt(1, 5) : 0;
            for (let j = 0; j < ones; j++) row[randomInt(0, N - 1)] = 1;
            out += row.join(' ') + '\n';
        }
        return out;
    },
    '18_max_subarray_diff': () => {
        let T = 1;
        let out = `${T}\n`;
        let N = randomInt(5, 10000);
        out += `${N}\n`;
        out += randomArray(N, -10000, 10000).join(' ') + '\n';
        return out;
    }
};

const NUM_TESTCASES = 50;

function generate() {
    const folders = fs.readdirSync(problemsDir).filter(f => fs.statSync(path.join(problemsDir, f)).isDirectory());

    folders.forEach(folder => {
        console.log(`Processing ${folder}...`);
        const pDir = path.join(problemsDir, folder);
        const testcasesDir = path.join(pDir, 'testcases');
        if (!fs.existsSync(testcasesDir)) fs.mkdirSync(testcasesDir);

        // Compile solution
        const solutionPath = path.join(pDir, 'solution.cpp');
        const exePath = path.join(pDir, 'solution.exe');
        
        if (fs.existsSync(solutionPath)) {
            console.log(` Compiling solution...`);
            const compile = spawnSync('g++', [solutionPath, '-o', exePath]);
            if (compile.status !== 0) {
                console.error(` Compilation failed for ${folder}:`, compile.stderr.toString());
                return;
            }
        } else {
            console.warn(` No solution.cpp found for ${folder}`);
            return;
        }

        const generator = generators[folder];
        if (!generator) {
            console.warn(` No generator found for ${folder}`);
            return;
        }

        console.log(` Generating ${NUM_TESTCASES} testcases...`);
        for (let i = 1; i <= NUM_TESTCASES; i++) {
            const inPath = path.join(testcasesDir, `input_${i}.txt`);
            const outPath = path.join(testcasesDir, `output_${i}.txt`);
            
            // Generate input
            const inputData = generator();
            fs.writeFileSync(inPath, inputData);

            // Run solution to generate output
            const run = spawnSync(exePath, { input: inputData, timeout: 2000 });
            if (run.status !== 0) {
                console.error(`  Run failed for testcase ${i} of ${folder}`);
                if (run.stderr) console.error(run.stderr.toString());
            } else {
                fs.writeFileSync(outPath, run.stdout.toString());
            }
        }
        console.log(` Done ${folder}\n`);
    });
}

generate();
